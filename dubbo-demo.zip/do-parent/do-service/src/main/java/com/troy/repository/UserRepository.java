package com.troy.repository;

import com.troy.domain.User;

public interface UserRepository extends BaseRepository<User,Long> {

}
