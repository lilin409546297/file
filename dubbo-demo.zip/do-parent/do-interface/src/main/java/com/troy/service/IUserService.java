package com.troy.service;

import com.troy.domain.User;

import java.util.List;

public interface IUserService {

    public List<User> findAll();
}
