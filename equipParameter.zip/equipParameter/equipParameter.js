var pNUM = 1;//页数，取得是默认值
var pSIZE = 20;//每页显示条数，取得是默认值
var curPsize = 10;
var EQUIDS = new Array();//存放被选中的设备的busiCode
var totalPAGES =  1;
var regEsn = /[^A-Za-z0-9]/;//0-16位之间字母数字
var regIp = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;//ip
var regAddr = /^([1-2][0-4]\d|25[0-4]|\d{1,2})$/;//0-254之间的整数
var regLon = /^((-|)(90|[1-8][0-9]|[0-9]))$/; //纬度
var regLat = /^((-|)(180|1[0-7]\d|\d{1,2}))$/;
var conditons = {};
var devIdList = [];//所选设备的ID集合
var signalKeyVal;
var stopPushFlag = false;
var flags=false;
var sureflags;
function getTheDate(t){
	var dt = new Date(t);
	return dt.getFullYear()+"-"+(dt.getMonth() + 1)+"-"+dt.getDate();//时间
}


$(function(){
	getArea();
	mac.setLanguage();
	onQuery();
	App.divDrag('win_add','h2winadd');
	$(document).on("click", "[name = 'target']", function(){
		stopWebsocket();
		stopPushFlag = true;
	});
});


/** 全选 */
function selectAll(obj){
	 if(obj.checked){                                              //全选
		 var signalinfo = $("input:checkbox[name='devcheck']");
		 if(signalinfo.size() > 0){
			 EQUIDS = new Array();
			 for(var i = 0;i < signalinfo.size();i++){
				 signalinfo.get(i).checked = true;
				 $('tr.ajaxData').addClass('mybgcolor')
				 EQUIDS.push(signalinfo.get(i).value);
			 }
		 }
	 }
	 else{                                                         //反选
		 var signalinfo = $("input:checkbox[name='devcheck']");
		 if(signalinfo.size() > 0){
			 for(var i = 0;i < signalinfo.size();i++){
				 signalinfo.get(i).checked = false;
				 $('tr.ajaxData').removeClass('mybgcolor');
			 }
			 EQUIDS = new Array();
		 }
	 }
}
/** 判断是否被选中 */
function resEquId(e){
	var id = e.defaultValue;
	if(e.checked){
		e.parentNode.parentNode.className='ajaxData mybgcolor';
		EQUIDS.push(id);
	}else{
		e.parentNode.parentNode.className='ajaxData';
		var index = 0;
		var flag = false;
		for(var i=0;i<EQUIDS.length;i++){
			if(EQUIDS[i] == id){
				index = i;
				flag = true;
				break;
			}
		}
		if(flag){
			EQUIDS.splice(index,1);
			flag = false;
		}
	}
	if(EQUIDS.length == curPsize){
		$("#selectAllId")[0].checked = true;
	}else{
		$("#selectAllId")[0].checked = false;
	}
}


function onDevParaConf(){
	$('#closeBtn').hide();
	$('#yincangBtn').show();
	$('#MPPTStatus').html('');
	$('#MPPTStatus').attr('title','');
    $('#sgsnStatus').html('');
	$('#sgsnStatus').attr('title','');
	$('#DWBZMStatus').html('');
    $('#DWBZMStatus').attr('title','');
    $('#ycglStatus').html('');
    $('#ycglStatus').attr('title','');
 	$('#MPPTRepair').html('');
 	$('#MPPTRepair').attr('title','');
 	$('#sgsnRepair').html('');
 	$('#sgsnRepair').attr('title','');
 	$('#DWBZMRepair').html('');
 	$('#DWBZMRepair').attr('title','');
 	$('#ycglRepair').html('');
 	$('#ycglRepair').attr('title','');
	$("#target").val("");
	var a = document.getElementsByName('devcheck');	
	var n = 0;
	devIdList = [];
	var num = 0;
	for(var i = 0;i<a.length;i++){
	    if(a[i].type == "checkbox"){
	    	if(a[i].checked== true){
	    		if(a[i].value!="" && a[i].value){
	    			num++;
	    			devIdList[n++] = a[i].value;
	    		}
	    	}
	    }
	}
	if(n==0){                                    //没有勾选
		var ts = Msg.rwmenu.devPara.devParaConf.devNone;
		App.myMsg(ts);
		return;
	}else{
		resetDiv('win_add');
		clearAddWindow(num);                    //根据设备类型来判断显示不同的界面
	}
}



function dwbzmCheck(){
	if(!(/(^[0-9]$)|(^[0-5][0-9]$)|(^[6][0-2]$)/.test($("#isConfDWBZM").val()))){
		$("#dwbzmcheck").show();
	}else{
		$("#dwbzmcheck").hide();
	}
}

function onSubmit(){
	debugger
	$('#MPPTRepair').html("");
	$('#sgsnRepair').html("");
	$('#DWBZMRepair').html("");
	var winDiv = $("#win_add");
	url = "/cm/devparameter/devParasSet";
	var mppt = 0;
	var wgsn = 0;
	var ycgl = 0;
	var dwbzm = "";
	if($("#isConfMPPT").is(':checked')){
		mppt = 1;
	}
	else{
		mppt = 0;
	}
	if($("#isConfWGSN").is(':checked')){
		wgsn = 1;
	}
	else{
		wgsn = 0;
	}
	if($('#isConfycgl').is(":checked")){
		ycgl = 1;
	}
	
	dwbzm = $("#isConfDWBZM").val();
	var dwbzmText = $("#isConfDWBZM option:selected").text();
	/*if(!(/(^[0-9]$)|(^[0-5][0-9]$)|(^[6][0-2]$)/.test(dwbzm))){
		$("#dwbzmcheck").show();
		return;
	}*/
	//增加一个电网标准码的校验
	var para = {
			       "devIds" : devIdList,
			       "signalValuesObj" : {
								    	   "mppt" : mppt,
								    	   "wgsn" : wgsn,
								    	   "dwbzm" : dwbzm,
								    	   "dwbzmText":dwbzmText,
								    	   "ycgl":ycgl
			                            }
	           }
	$('#delLoadingtText').html(Msg.rwmenu.devPara.devParaConf.pidLoading);
	$('#sysMainOverlay').show();
	$('#delLoading').show();
	$.omcAjax(url,para,function(data){
		$('#sysMainOverlay').hide();
		$('#delLoading').hide();
		//$('#yincangBtn').hide();
		//$('#closeBtn').show();
	   if (data && data.success) {
		   var mStatus = $('#MPPTStatus');
		   var sStatus = $('#sgsnStatus');
		   var dStatus = $('#DWBZMStatus');
		   var ycglStatus = $('#ycglStatus');
		   //失败的title信息
		   var mStr = '';
		   var sStr = '';
		   var dStr = '';
		   var ycglStr ='';
		   //修复建议的title信息
		   var mSuggestion = '';
		   var sSuggestion = '';
		   var dSuggestion = '';
		   var ycglSuggestion = '';
		   //成功状态
		   var mFlag = true;
		   var sFlag = true;
		   var dFlag = true;
		   var ycglFlag = true;
		   var sMap = data.data;
		   for(var key in sMap){
			   var arr = sMap[key];
			   if(arr[0] == 'fail'){
				   mFlag = false;
				   mStr = mStr + key +Msg.rwmenu.devPara.devParaConf.fail+' '; 
				   mSuggestion = mSuggestion + key + mac.vals(arr[1]) + ';';
			   }
			   if(arr[2] == 'fail'){
				   sFlag = false;
				   sStr = sStr + key +Msg.rwmenu.devPara.devParaConf.fail+' ';
				   sSuggestion = sSuggestion + key + mac.vals(arr[3]) + ';';
			   }
			   if(arr[4] == 'fail'){
				   dFlag = false;
				   dStr = dStr + key +Msg.rwmenu.devPara.devParaConf.fail+' ';
				   dSuggestion = dSuggestion + key + mac.vals(arr[5]) + ';';
			   }
			   if(arr[6] == 'fail'){
				   ycglFlag = false;
				   ycglStr = ycglStr + key +Msg.rwmenu.devPara.devParaConf.fail+' ';
				   ycglSuggestion = ycglSuggestion + key + mac.vals(arr[7]) + ';';
			   }
		   }
		   var mSub = mSuggestion.length>15?mSuggestion.substring(0,12)+'...':mSuggestion;
		   var sSub = sSuggestion.length>15?sSuggestion.substring(0,12)+'...':sSuggestion;
		   var dSub = dSuggestion.length>15?dSuggestion.substring(0,12)+'...':dSuggestion;
		   var ycglSub = ycglSuggestion.length>15?ycglSuggestion.substring(0,12)+'...':ycglSuggestion;
		   if(mFlag){
			   mStatus.html(Msg.rwmenu.devPara.devParaConf.success);
			   mStatus.css('color','#00de15');
		   }else{
			   mStatus.html(Msg.rwmenu.devPara.devParaConf.fail);
			   mStatus.attr('title',mStr);
			   mStatus.css('color','red');
			   $('#MPPTRepair').html(mSub);
			   $('#MPPTRepair').attr('title',mSuggestion);
		   }
		   if(sFlag){
			   sStatus.html(Msg.rwmenu.devPara.devParaConf.success);
			   sStatus.css('color','#00de15');
		   }else{
			   sStatus.html(Msg.rwmenu.devPara.devParaConf.fail);
			   sStatus.attr('title',sStr);
			   sStatus.css('color','red');
			   $('#sgsnRepair').html(sSub);
			   $('#sgsnRepair').attr('title',sSuggestion);
		   }
		   if(dFlag){
			   dStatus.html(Msg.rwmenu.devPara.devParaConf.success);
			   dStatus.css('color','#00de15');
		   }else{
			   dStatus.html(Msg.rwmenu.devPara.devParaConf.fail);
			   dStatus.attr('title',dStr);
			   dStatus.css('color','red');
			   $('#DWBZMRepair').html(dSub);
			   $('#DWBZMRepair').attr('title',dSuggestion);
		   }
		    if(ycglFlag){
		   	   ycglStatus.html(Msg.rwmenu.devPara.devParaConf.success);
			   ycglStatus.css('color','#00de15');
		    }else{
		    	ycglStatus.html(Msg.rwmenu.devPara.devParaConf.fail);
			    ycglStatus.attr('title',ycglStr);
			    ycglStatus.css('color','red');
			    $('#ycglRepair').html(ycglSub);
			    $('#ycglRepair').attr('title',ycglSuggestion);
		    }
//		    App.myMsg(Msg.rwmenu.devPara.devParaConf.ordersendsuc);
//	    	winDiv.hide();
//	    	$("#overlay").hide();
		    onQuery();
	     }
	     else{
	    	App.myMsg(Msg.rwmenu.devPara.devParaConf.overTime);
	    	winDiv.hide();
	    	$("#overlay").hide();
	    	onQuery();
	     }
	 });
}

function pid3Window(){
	stopPushFlag = false;
	$("#addButton").attr('onclick', 'setpidf()');
	$("#inverset").hide();
	$("#inverset1").hide();
	$("#inverset2").hide();
	$("#inverset3").hide();
	$("#inverset4").hide();
	$("#inverset5").hide();
	$("#setpid").show();
	$('#win_add').show();
	$('#overlay').show();
}

function clearAddWindow(num){
	debugger;
	var devType = $("#dev").val();
	if(devType == 2 || devType == 3){
		stopPushFlag = false;
		signalPointFind(num);
		$("#addButton").attr('onclick', 'setpidf()');
		$("#inverset").hide();
		$("#inverset1").hide();
		$("#inverset2").hide();
		$("#inverset3").hide();
		$("#inverset4").hide();
		$("#inverset5").hide();
		$("#setpid").show();
		$('#win_add').show();
		$('#overlay').show();
	}else if(devType == 4 || devType == 5){
		pid3Window();
		signalPointFind_repair();
	}else{
		$("#addButton").attr('onclick', 'onSubmit()');                 //逆变器设备
		$("#inverset").show();
		$("#inverset1").show();
		$("#inverset2").show();
		$("#inverset3").show();
		$("#inverset4").show();
		$("#inverset5").show();
		$("#dwbzmcheck").hide();
		$("#setpid").hide();
		$("#isConfDWBZM").html("");                                     //电网标准码输入值清空

        // 开始加载
        $("#saveDevConfigHH").show();
        $('#saveDLoadingtTextN').html(Msg.opticaltracking.nowUnderwayPleaseWait);
        $('#saveDLoadingN').show();

        //请求获取电网标准码信息
        $.omcAjax("/cm/devparameter/getGridStdCode",{"devIds":devIdList},function(result){
            $("#saveDevConfigHH").hide();
            $('#saveDLoadingN').hide();
            if(result.success){
                var dataList = result.data;
                if(dataList && dataList.length > 0){
                    $("#isConfDWBZM").append("<option  value='-1' >"+ Msg.rwmenu.devPara.devParaConf.plechose +"</option>");
                    for(var k = 0 ; k < dataList.length ; k++){
                        if( dataList[k] != null && dataList[k].name!="VDE-AR-N-4105-MV480"){
                            var option = "<option  value='"+ dataList[k].codeSeq +"' >"+ dataList[k].name +"</option>";
                            $("#isConfDWBZM").append(option);
                        }
                    }
                }
                else{
                    //alert("获取电网标准码信息失败");
                    $("#isConfDWBZM").append("<option  value='-1' >"+ Msg.rwmenu.devPara.devParaConf.plechose +"</option>");
                }
            }
            else{
                //alert("获取电网标准码信息失败");
                $("#isConfDWBZM").append("<option  value='-1' >"+ Msg.rwmenu.devPara.devParaConf.plechose +"</option>");
            }
            $('#win_add').show();
            $('#overlay').show();
            if(1 == devIdList.length){                                                                //只选了一个设备的话就应该
                $.omcAjax("/cm/devparameter/getdevParas",{devIds:devIdList},function(result){
                    if(result.success && result.data){
                        //选中电网标准码
                        var dwbzmValue= result.data.dwbzm;
                        if(dwbzmValue == 0 || dwbzmValue){
                            $("#isConfDWBZM option[value="+ dwbzmValue +"]").attr("selected", "selected");
                        }
                        $("#isConfMPPT")[0].checked = result.data.mppt && 1;
                        $("#isConfWGSN")[0].checked = result.data.wgsn && 1;
                        $("#isConfycgl")[0].checked = result.data.ycgl && 1;
                    }
                    $("#isConfDWBZM").comboSelect();
                });
            }else{
                if($("#isConfMPPT")[0].checked){
                    $("#isConfMPPT")[0].checked = false;
                }
                if($("#isConfWGSN")[0].checked){
                    $("#isConfWGSN")[0].checked = false;
                }
                if($("#isConfycgl")[0].checked){
                    $("#isConfycgl")[0].checked = false;
                }
                $("#isConfDWBZM").comboSelect();
            }
        });

	}
}

function search(){
	var sCondition = {};
	
	var areaId = $("#area option:selected").val();
	var subarrayId = $("#subarray option:selected").val();
	
	sCondition.areaId = areaId;
	sCondition.subarrayId = subarrayId;
	conditons = sCondition;
	toFirstPage();
}
function resetDiv(id){
	debugger;
	$("#"+id).css("top",'12%');
	$("#"+id).css("left",'33%');
	$('#portNum').show();
	$('#ESNadd').show();
	$('#protocolAddradd').show();
	
	$('#portNumUp').show();
	$('#ESN').show();
	$('#protocolAddr').show();
	
	$('#portNum').val('');
	$('#ESNadd').val('');
	$('#ipadd').val('');
	$('#portNumUp').val('');
	$('#ESN').val('');
	$('#protocolAddr').val('');
	
}
/** 查询设备信息 */
function onQuery(){
	var pageNum = pNUM;
	var pageSize = pSIZE;
	var parm = {};
	if(conditons!=null && undefined!=conditons){
		var ss = JSON.stringify(conditons);
		parm = mac.eval(ss);
	}
	parm.pageNum = pageNum;
	parm.pageSize = pageSize;
	parm.areaId = $("#area option:selected").val();
	parm.subarrayId = $("#subarray option:selected").val();
	var devType = $("#dev").val();
	parm.devType = devType;
	$.omcHttp.POST("/devices/queryHw",parm,function(res){
		if(res.success){
			//removeData();
			$('#equip tr').remove();
			var rd = res.data;
	//修改问题单15666 【IES3.0- R003C00CP0005B031】【eSCS910-ET】【独立团队】【设备参数设置】设备参数设置切换设备后，页码显示错误 没有导入点表的情况
			if(rd == null){ 
			    totalPage = 1;
			    currentPage = 1;
			    total = 0;
			    totalPAGES = totalPage;
				pNUM = currentPage;
				
				EQUIDS = new Array();
				var tab = $('#equip');
				curPsize = 1;
			}else{
				var infoData = rd.objects;
				var currentPage = rd.currentPage;
				var offset = rd.offset;
				var pageSize = rd.pageSize;
				var realSize = rd.realSize;
				var total = rd.total;
				var totalPage = rd.totalPage;
				if(totalPage<=0){
				    totalPage = 1;
				}
				if(currentPage<=0){
				    currentPage = 1;
	            }
				totalPAGES = totalPage;
				pNUM = currentPage;
				
				EQUIDS = new Array();
				var tab = $('#equip');
				for(var i=0;i<infoData.length;i++){
					var tr = $('<tr class="ajaxData"></tr>');
					tr.append("<td width='3.5%' height='40' align=\"center\" valign=\"middle\"><input class=\"checkbox\" name=\"devcheck\" type=\"checkbox\" style=\"width: 16px; height: 16px\" onclick='resEquId(this)' value="+ infoData[i].id +" /></td>");
					tr.append("<td width='15%' align='center' valign='middle'> <input type='text' class='talbleInputSys' readonly='true' title='"+getNullByValue(App.escapseHtml(infoData[i].name))+"' value='"+getNullByValue(App.escapseHtml(infoData[i].name))+"' /></td>");
					tr.append("<td width='11%' align='center' valign='middle' style='display: none;'> <input type='text' class='talbleInputSys' readonly='true' title='"+getNullByValue(App.escapseHtml(infoData[i].busiCode))+"' value='"+getNullByValue(App.escapseHtml(infoData[i].busiCode))+"' /></td>");
					tr.append("<td width='12%' align='center' valign='middle'><input type='text' class='talbleInputSys' readonly='true' title='"+getNullByValue(infoData[i].ESN)+"' value='"+getNullByValue(infoData[i].ESN)+"' /></td>");
					tr.append("<td class='talbleTdSys' style='width:12%;max-width:10px;' width='12%' align='center' valign='middle' title='"+getNullByValue(infoData[i].ip)+"'>"+getNullByValue(infoData[i].ip)+"</td>");
					tr.append("<td class='talbleTdSys' style='width:12%;max-width:10px;' width='12%' align='center' valign='middle' title='"+getNullByValue(infoData[i].protocolAddr)+"'>"+getNullByValue(infoData[i].protocolAddr)+"</td>");
					tr.append("<td class='talbleTdSys' style='width:11%;max-width:10px;' width='11%' align='center' valign='middle' title='"+getNullByValue(infoData[i].dataModelVersion)+"' >"+getNullByValue(infoData[i].dataModelVersion)+"</td>");
					if(infoData[i].subAreaName && infoData[i].subMatrixName){
						tr.append("<td width='9%' align='center' valign='middle'> <input type='text' class='talbleInputSys' readonly='true' title='"+getNullByValue(infoData[i].subAreaName+" "+infoData[i].subMatrixName)+"' value='"+getNullByValue(infoData[i].subAreaName+" "+infoData[i].subMatrixName)+"' /></td>");
					}else{
						tr.append("<td width='9%' align='center' valign='middle'> <input type='text' class='talbleInputSys' readonly='true' title='"+getNullByValue(infoData[i].lowVCircuitBreaker2)+"' value='"+getNullByValue(infoData[i].lowVCircuitBreaker2)+"' /></td>");
					}
					tr.append("<td width='6%' align='center' valign='middle'>"+getNullByValue(infoData[i].longitude)+"</td>");     
					tr.append("<td width='6%' align='center' valign='middle'>"+getNullByValue(infoData[i].latitude)+"</td>");
					tr.append("<td style='max-width:10px;' class='timelang talbleTdSys il8n-title' timelang='"+infoData[i].createDate+"' title='"+getDate(infoData[i].createDate)+"' align='center' valign='middle'>"+getDate(infoData[i].createDate)+"</td>");
					tab.append(tr);
	            }
				curPsize = infoData.length;
			}
			
			$("#totalNum").html(total);
			$("#totalPageId").html(totalPage);
			$("#cuPage").html(currentPage);
//			setPlural("totalNum","totalNum1");
//			setPlural("totalPageId","totalPageId1");
			parent.autoTableSize();
			var pnum = $("#pageNumId").val(pNUM);
			funClicktrSelect('tr.ajaxData','input.checkbox','selectAllId');
		}
	});
	$("#selectAllId")[0].checked = false;//*****
	
	$(".turnpage").show();
}

$('#pageNumId').keyup(function(e){ 
	var cur = $("#cuPage").html();
	var curkey = e.which; 
	var tzCount = $("#pageNumId").val();
	var reg = /^[0-9]*$/;
	if(tzCount!="" && reg.test(tzCount)){
		if(totalPAGES < tzCount){
			pNUM = totalPAGES;
			$("#pageNumId").val(totalPAGES);
		}else{
			pNUM = tzCount;
			if(pNUM == 0){
				pNUM = 1;
			}
		}
		onQuery();
	}else{
		if(tzCount!=""){
			$("#pageNumId").val(cur);
		}
		return false;
	}
});
/**
 * 获取电站分区
 */
function getArea(){
	$.omcAjax("/healthycheck/getArea",{},function(res){
		if(res && res.success && res.data){
			var area = res.data;
			for(var i=0;i<area.length;i++){
				$('#area').append("<option value=\""+area[i].id+"\" >"+area[i].name+"</option>");
			}
		}
	});
};


/**
 * 分区改变动态获取所选分区下的所有子阵
 */
function getSubarray(){
	//change事件发生时 请求第一页的数据
	pNUM = 1;
	var areaId = $('#area').val();
	$('#subarray').html("<option value=\"0\" selected=\"selected\">"+Msg.rwmenu.devPara.devParaConf.allSubarray+"</option>");
	if(areaId==0){
		onQuery();
		return;
	}
	$.omcAjax("/healthycheck/getSubarray",{"areaId":areaId},function(res){
		if(res && res.success && res.data){
			var sub = res.data;
			for(var i=0;i<sub.length;i++){
				$('#subarray').append("<option value=\""+sub[i].id+"\" >"+sub[i].name+"</option>");
			}
		}
	});
	onQuery();
};

/** 设置每页显示多少行 */
function onChangePageSelectId(){
	var psize = $("#pageSelectId").val();
	pSIZE = psize;
	pNUM = 1;
	onQuery();
}

/** 跳到第一页 */
function toFirstPage(){
	$("#pageNumId").val(1);
	pNUM = 1;
	onQuery();
}

/** 跳到上一页 */
function toBeforePage(){
	var cur = $("#cuPage").html();
	if((Number(cur)-1)>0){
		pNUM = Number(cur)-1;
	}
	if(cur == pNUM){
		return;
	}
	onQuery();
}

/** 跳到下一页 */
function toAfterPage(){
	var cur = $("#cuPage").html();
	if((Number(cur)+1)<= totalPAGES){
		pNUM = Number(cur)+1;
	}
	if(cur == pNUM){
		return;
	}
	onQuery();
}

/** 跳到最后一页 */
function toLastPage(){
	var cur = $("#cuPage").html();
	$("#pageNumId").val(totalPAGES);
	pNUM = totalPAGES;
	if(cur == pNUM){
		return;
	}
	onQuery();
}

function closeAddWindow(){
	stopWebsocket();
	document.getElementById('overlay').style.display="none";
	document.getElementById('win_add').style.display="none";
	stopPushFlag = false;
//	document.getElementById('protNumberHidden').style.display="";

}

function getDevs(){
	//change事件发生时 请求第一页的数据
	pNUM = 1;
	onQuery();
}
function signalPointFind_repair(){
	var tr = $("#pid-equipment");
	tr.empty();
	tr.append("<tr><td align='center' valign='middle' style='width:30%'><b>"+Msg.rwmenu.devPara.devParaConf.signalPoint+"</b></td>" +
			"<td align='center' valign='middle'><b>"+Msg.rwmenu.devPara.devParaConf.targetValue+"</b></td><td width='180'></td>"+
			"<td align='center' valign='middle'>"+Msg.rwmenu.devPara.devParaConf.operationResult+"</td></tr>");
	var trInput = "";
	var trInputOld = "";
	var trSelects = "";
	var flag = false;
	var devType = $("#dev").val();
	if(5 == devType){
		flag = true;
	}
	if(devIdList && "" != devIdList){
		$('#sysMainOverlay').show();
        $('#delLoading').show();
        $('#delLoadingtText').html("");
		$.omcAjax("/devices/findPid3Sig",{"devIdList":devIdList, "flag":flag},function(res){
			if(res && res.success && res.data){
				var sigLisst = res.data.sigList;
				var sigVal = res.data.sigVal;
				if(sigLisst != null){
					for(var i=0; i<sigLisst.length; i++){
						trSelects = "";
						trInput = "";
						var trSelect = "<tr><td height='40' align='center' valign='middle'><div style='text-align:center;'>"+ getLangs(sigLisst[i].sigAddress,flag) + "</div></td><td width='180' align='center' valign='middle' id='"+sigLisst[i].colName+"' name='signame'>";
						
						if(flag && sigLisst[i].sigAddress == 45059){
							trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+getValue(sigVal[sigLisst[i].id])+"' type='text' size='10' onkeyup='pid3_repairTime()'/>h</td><td width='130'><span style='color:red;'>*</span><span id='pid3_repairTime' style='color:red;'></span>";
							trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
						}else if(flag && sigLisst[i].sigAddress == 45060){
							trInput += trSelect+"<input name='target' value='"+getValue(sigVal[sigLisst[i].id])+"' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pid3_repairVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pid3_repairVoltage' style='color:red;'></span>";
							trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
						}else if(sigLisst[i].sigAddress == 45001){//工作模式([0,1],0：正常1：调试)
							var tempStr = "<option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></select>";
							var tempValue = getValue(sigVal[sigLisst[i].id]);
							if(tempValue === 0 || tempValue === "0"){
								tempStr = "<option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></select>"
							}else if(tempValue === 1 || tempValue === "1"){
								tempStr = "<option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option><option value='1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></select>"
							}
							trSelects = trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'>" +tempStr;
						}else if(sigLisst[i].sigAddress == 45002){
							trInput += trSelect+"<input name='target' class='input-style2' value='"+getValue(sigVal[sigLisst[i].id])+"' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pid3_debugOutputVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pid3_debugOutputVoltage' style='color:red;'></span>";
							trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
						}

                        /** else if(sigLisst[i].sigAddress == 45020){//清除数据([0,1],1：不清除,0：清除)
							var tempStr = "<option value='1'>"+Msg.rwmenu.devPara.devParaConf.pid3_noClean+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pid3_clean+"</option></select>";
							if(tempValue === 0 || tempValue === "0"){
								tempStr = "<option value='1'>"+Msg.rwmenu.devPara.devParaConf.pid3_noClean+"</option><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pid3_clean+"</option></select>";
							}else if(tempValue === 1 || tempValue === "1"){
								tempStr = "<option value='1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pid3_noClean+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pid3_clean+"</option></select>";
							}
							trSelects = trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'>" +tempStr;
						} **/
						
						if(trInputOld == trInput){
							trSelects += "</td><td></td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
						}else{
							trSelects += "</td></tr>";
						}
						tr.append(trSelects);
						tr.append(trInput);
					}
					flags=false;
					toggleIMD();
					
				}
				if(sigVal != null){
					$("#current").val(sigVal);
				}
				
				pid3_debugOutputVoltage();
				if(flag){
					pid3_repairTime();
					pid3_repairVoltage();
				}
			}
			$('#sysMainOverlay').hide();
	        $('#delLoading').hide();
		});
	}
}

function getValue(value){
	if(value===undefined || value ===null || value === "#" || value=== ""){
		return "";
	}
	return value;
}


function signalPointFind(num){
	var tr = $("#pid-equipment");
	tr.empty();
	tr.append("<tr><td align='center' valign='middle' style='width:30%'><b>"+Msg.rwmenu.devPara.devParaConf.signalPoint+"</b></td>" +
			"<td align='center' valign='middle'><b>"+Msg.rwmenu.devPara.devParaConf.targetValue+"</b></td><td width='180'></td>"+
			"<td align='center' valign='middle'>"+Msg.rwmenu.devPara.devParaConf.operationResult+"</td></tr>");
	var trInput = "";
	var trInputOld = "";
	var trSelects = "";
	var flag = false;
	var devType = $("#dev").val();
	if(3 == devType){
		flag = true;
	}
	if(devIdList && "" != devIdList){
		$('#sysMainOverlay').show();
        $('#delLoading').show();
        $('#delLoadingtText').html("");
		$.omcAjax("/devices/findPidSig",{"devIdList":devIdList, "flag":flag},function(res){
			if(res && res.success && res.data){
				var sigLisst = res.data.sigList;
				var sigVal = res.data.sigVal;
				if(sigLisst != null){
					for(var i=0; i<sigLisst.length; i++){
						trSelects = "";
						var trSelect = "<tr><td height='40' align='center' valign='middle'><div style='text-align:center;'>"+ getLangs(sigLisst[i].sigAddress,flag) + "</div></td><td width='180' align='center' valign='middle' id='"+sigLisst[i].colName+"' name='signame'>";
						if(num > 1){
							if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidControlModes){
								if(flag){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='2'>N/PE</option></select>";
								} else{
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='1'>PV/PE</option><option value='2'>N/PE</option><option value='3'>"+Msg.rwmenu.devPara.devParaConf.pidAutomatic+"</option></select>";
								}
							}
							else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidOutputEnable){
								trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
							}
							else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.BatteryBoardType){
								trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidPType+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidNType+"</option></select>";
							} else if(flag && sigLisst[i].sigAddress == 45005){
								trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.stationStatusConfig.pidsetzOffset+"</option><option value='1'>"+Msg.stationStatusConfig.pidsetfOffset+"</option></select>";
							}
							else{
								if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidOutputVoltage){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pidOutputVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidOutputVoltage' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}
								else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidCompensatingVoltage){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pidCompensatingVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidCompensatingVoltage' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}
								else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.maxDCVoltage){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='maxDCVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='maxDCVoltage' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45021){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pidOutputVoltageV2()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidOutputVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45022){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pidjlV2()'/>kΩ</td><td width='130'><span style='color:red;'>*</span><span id='pidjlVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45023){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pidbcV2()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidbcVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45029){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='pidzgjlV2()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidzgjlVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}else if(sigLisst[i].sigAddress == 45001){//工作模式([0,1],0：正常1：调试)	v1/v2
									if ($("#dev").val() == 3) {
                                        trSelects += trSelect + "<select onchange='changeOperatingMode(this)' style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'></option><option value='0'>" + Msg.rwmenu.devPara.devParaConf.pidNormal + "</option><option value='1'>" + Msg.rwmenu.devPara.devParaConf.pidDebug + "</option></select>";
                                    } else {
                                        trSelects += trSelect + "<select style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'></option><option value='0'>" + Msg.rwmenu.devPara.devParaConf.pidNormal + "</option><option value='1'>" + Msg.rwmenu.devPara.devParaConf.pidDebug + "</option></select>";
									}
								}else if(sigLisst[i].sigAddress == 45044){//IMD设备接入([0,1],0:禁能 1:使能) v1/v2
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}else if(sigLisst[i].sigAddress == 45046){//IMD周期运行时间([15,480],如果“IMD设备接入“设置为“禁止“，UI界面不显示)	v1/v2
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='imdRecTime()'/>Min</td><td width='130'><span style='color:red;'>*</span><span id='imdRecTime' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}else if(sigLisst[i].sigAddress == 45045){//PID周期运行时间([60,480],如果“IMD设备接入“设置为“禁止“，UI界面不显示) v1/v2
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' type='text' size='10' onkeyup='imdRecTime()'/>Min</td><td width='130'><span style='color:red;'>*</span><span id='pidRecTime' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id='"+ sigLisst[i].id +"' title=''></span></td></tr>";
								}else if(sigLisst[i].sigAddress == 45047){//IMD控制干接点([1,3],1：DO1；2：DO2；3：DO3；如果“IMD设备接入“设置为“禁止“，UI界面不显示) v1
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'></option><option value='1'>DO1</option><option value='2'>DO2</option><option value='3'>DO3</option></select>";
								}
							}
						}
						else{
							if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidControlModes){ //补偿方式 v1/v2	0:禁止 1:PV/PE(仅V1支持) 2:N/PE 3:自动(仅V1支持)
								if(sigVal[sigLisst[i].id] == 0){
									if(!flag){
										trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='1'>PV/PE</option><option value='2'>N/PE</option><option value='3'>"+Msg.rwmenu.devPara.devParaConf.pidAutomatic+"</option></select><span style='color:red;'>*</span>";
									}else{
										trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='2'>N/PE</option></select><span style='color:red;'>*</span>";
									}
									
								} else if(sigVal[sigLisst[i].id] == 1 && !flag){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='1' selected='selected'>PV/PE</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='2'>N/PE</option><option value='3'>"+Msg.rwmenu.devPara.devParaConf.pidAutomatic+"</option></select><span style='color:red;'>*</span>";
								}else if(sigVal[sigLisst[i].id] == 2){
									if(!flag){
										trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='2' selected='selected'>N/PE</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='1'>PV/PE</option><option value='3'>"+Msg.rwmenu.devPara.devParaConf.pidAutomatic+"</option></select><span style='color:red;'>*</span>";
									}else{
										trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='2' selected='selected'>N/PE</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option></select><span style='color:red;'>*</span>";
									}
									
								}else if(sigVal[sigLisst[i].id] == 3 && !flag){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='3' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidAutomatic+"</option><option value='1' >PV/PE</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='2'>N/PE</option></select><span style='color:red;'>*</span>";
								}else{
									if(!flag){
										trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='1'>PV/PE</option><option value='2'>N/PE</option><option value='3'>"+Msg.rwmenu.devPara.devParaConf.pidAutomatic+"</option></select><span style='color:red;'>*</span>";
									}else{
										trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidBan+"</option><option value='2'>N/PE</option></select><span style='color:red;'>*</span>";
									}
								}
							}
							else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidOutputEnable){
								if(sigVal[sigLisst[i].id] == 0){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								} else if(sigVal[sigLisst[i].id] == null){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select><span style='color:red;'>*</span>";
								}
								else{
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}
							}
							else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.BatteryBoardType){
								if(sigVal[sigLisst[i].id] == 0){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidPType+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidNType+"</option></select>";
								} else if(sigVal[sigLisst[i].id] == null){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.devPara.pidSelectd+"</option><option value='0'>"+Msg.devPara.pidPType+"</option><option value='1'>"+Msg.devPara.pidNType+"</option></select><span style='color:red;'>*</span>";
								}
								else{
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidPType+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidNType+"</option></select>";
								}
							} else if(flag && sigLisst[i].sigAddress == 45005){
                                var dev = $("#dev").val();
								if(sigVal[sigLisst[i].id] == 0){
                                    if (dev == 3) {
                                        trSelects += trSelect + "<select disabled='disabled' style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='0' selected='selected'>" + Msg.stationStatusConfig.pidsetzOffset + "</option><option value='1'>" + Msg.stationStatusConfig.pidsetfOffset + "</option></select><span style='color:red;'>*</span>";
                                    } else {
                                        if (dev == 3) {
                                            trSelects += trSelect + "<select disabled='disabled' style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='0' selected='selected'>" + Msg.stationStatusConfig.pidsetzOffset + "</option><option value='1'>" + Msg.stationStatusConfig.pidsetfOffset + "</option></select><span style='color:red;'>*</span>";
                                        } else {
                                            trSelects += trSelect + "<select style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='0' selected='selected'>" + Msg.stationStatusConfig.pidsetzOffset + "</option><option value='1'>" + Msg.stationStatusConfig.pidsetfOffset + "</option></select><span style='color:red;'>*</span>";
                                        }
                                    }
								} else if(sigVal[sigLisst[i].id] == 1){
                                    if (dev == 3) {
                                        trSelects += trSelect + "<select disabled='disabled' style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='1' selected='selected'>" + Msg.stationStatusConfig.pidsetfOffset + "</option><option value='0'>" + Msg.stationStatusConfig.pidsetzOffset + "</option></select><span style='color:red;'>*</span>";
                                    } else {
                                        trSelects += trSelect + "<select style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='1' selected='selected'>" + Msg.stationStatusConfig.pidsetfOffset + "</option><option value='0'>" + Msg.stationStatusConfig.pidsetzOffset + "</option></select><span style='color:red;'>*</span>";
									}
								}
								else{
                                    if (dev == 3) {
                                        trSelects += trSelect + "<select disabled='disabled' style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='-1' selected='selected'>" + Msg.rwmenu.devPara.devParaConf.pidSelectd + "</option><option value='0'>" + Msg.stationStatusConfig.pidsetzOffset + "</option><option value='1'>" + Msg.stationStatusConfig.pidsetfOffset + "</option></select><span style='color:red;'>*</span>";
                                    } else {
                                        trSelects += trSelect + "<select style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='-1' selected='selected'>" + Msg.rwmenu.devPara.devParaConf.pidSelectd + "</option><option value='0'>" + Msg.stationStatusConfig.pidsetzOffset + "</option><option value='1'>" + Msg.stationStatusConfig.pidsetfOffset + "</option></select><span style='color:red;'>*</span>";
									}
								}
							}
							else if(sigLisst[i].sigAddress == 45001){	//工作模式([0,1],0：正常1：调试)	v1/v2
                                var dev = $("#dev").val();
								if(sigVal[sigLisst[i].id] == 0){
									if (dev == 2 || dev == 3) {
                                        trSelects += trSelect+"<select disabled='disabled' style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></select>";
									} else {
                                        trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></select>";
									}
								}else if(sigVal[sigLisst[i].id] == 1){
                                    if (dev == 2 || dev == 3) {
                                        trSelects += trSelect+"<select disabled='disabled' style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option></select>";
                                    } else {
                                        trSelects += trSelect+"<select  style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option></select>";
									}
								}else{
                                    if (dev == 2 || dev == 3) {
                                        trSelects += trSelect + "<select disabled='disabled'style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='-1' selected='selected'>" + Msg.rwmenu.devPara.devParaConf.pidSelectd + "</option><option value='0'>" + Msg.rwmenu.devPara.devParaConf.pidNormal + "</option><option value='1'>" + Msg.rwmenu.devPara.devParaConf.pidDebug + "</option></select>";
									} else {
                                        trSelects += trSelect + "<select style='float:left;' name='target' class='xialaliebiao' id='" + sigLisst[i].id + "'><option value='-1' selected='selected'>" + Msg.rwmenu.devPara.devParaConf.pidSelectd + "</option><option value='0'>" + Msg.rwmenu.devPara.devParaConf.pidNormal + "</option><option value='1'>" + Msg.rwmenu.devPara.devParaConf.pidDebug + "</option></select>";
                                    }
								}
							}
							else if(sigLisst[i].sigAddress == 45044){	//IMD设备接入([0,1],0:禁能 1:使能) v1/v2
								if(sigVal[sigLisst[i].id] == 0){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'></option><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}else if(sigVal[sigLisst[i].id] == 1){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'><option value='1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option></select>";
								}else{
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'></option><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}
							}
							else if(sigLisst[i].sigAddress == 45047 && !flag){//IMD控制干接点([1,3],1：DO1；2：DO2；3：DO3；如果“IMD设备接入“设置为“禁止“，UI界面不显示) v1
								if(sigVal[sigLisst[i].id] == 1){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='1' selected='selected'>DO1</option><option value='2'>DO2</option><option value='3'>DO3</option></select>";
								}else if(sigVal[sigLisst[i].id] == 2){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='2' selected='selected'>DO2</option><option value='1'>DO1</option><option value='3'>DO3</option></select>";
								}else if(sigVal[sigLisst[i].id] == 3){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='3' selected='selected'>DO3</option><option value='1'>DO1</option><option value='2'>DO2</option></select>";
								}else{
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='1'>DO1</option><option value='2'>DO2</option><option value='3'>DO3</option></select>";
								}
							}else if(sigLisst[i].sigAddress == 45004){
								if(sigVal[sigLisst[i].id] == 0){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'></option><option value='0' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}else if(sigVal[sigLisst[i].id] == 1){
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'><option value='1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option></select>";
								}else{
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'></option><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}
							}
							else{
								var value = sigVal[sigLisst[i].id];
								if(value == null || value == "—"){
									value = "";
								}
								if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidOutputVoltage){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='pidOutputVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidOutputVoltage' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}
								else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.pidCompensatingVoltage){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='pidCompensatingVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidCompensatingVoltage' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}
								else if(getLangs(sigLisst[i].sigAddress,flag) == Msg.rwmenu.devPara.devParaConf.maxDCVoltage){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='maxDCVoltage()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='maxDCVoltage' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45021){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='pidOutputVoltageV2()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidOutputVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45022){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='pidjlV2()'/>kΩ</td><td width='130'><span style='color:red;'>*</span><span id='pidjlVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45023){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='pidbcV2()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidbcVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}else if(flag && sigLisst[i].sigAddress == 45029){
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='pidzgjlV2()'/>V</td><td width='130'><span style='color:red;'>*</span><span id='pidzgjlVoltageV2' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}else if(sigLisst[i].sigAddress == 45001){//工作模式([0,1],0：正常1：调试)	v1/v2
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidNormal+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidDebug+"</option></select>";
								}else if(sigLisst[i].sigAddress == 45044){//IMD设备接入([0,1],0:禁能 1:使能) v1/v2
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}else if(sigLisst[i].sigAddress == 45046){//IMD周期运行时间([15,480],如果“IMD设备接入“设置为“禁止“，UI界面不显示)	v1/v2
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='imdRecTime()'/>Min</td><td width='130'><span style='color:red;'>*</span><span id='imdRecTime' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
								}else if(sigLisst[i].sigAddress == 45045){//PID周期运行时间([60,480],如果“IMD设备接入“设置为“禁止“，UI界面不显示) v1/v2
									trInput += trSelect+"<input name='target' class='input-style2' style=\"background: url('/images/input-pidText.png') 0 bottom no-repeat; color:#4aa3dc; border:none; height: 30px; width: 153px; float:left;\" id='"+sigLisst[i].id+"' value='"+value+"' type='text' size='10' onkeyup='imdRecTime()'/>Min</td><td width='130'><span style='color:red;'>*</span><span id='pidRecTime' style='color:red;'></span>";
									trInput += "</td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title='' ></span></td></tr>";
								}else if(sigLisst[i].sigAddress == 45047){//IMD控制干接点([1,3],1：DO1；2：DO2；3：DO3；如果“IMD设备接入“设置为“禁止“，UI界面不显示) v1
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"'><option value='-1' selected='selected'>"+Msg.rwmenu.devPara.devParaConf.pidSelectd+"</option><option value='1'>DO1</option><option value='2'>DO2</option><option value='3'>DO3</option></select>";
								}else if(sigLisst[i].sigAddress == 45004){//输出使能
									trSelects += trSelect+"<select style='float:left;' name='target' class='xialaliebiao' id='"+sigLisst[i].id+"' onchange='toggleIMD()'></option><option value='0'>"+Msg.rwmenu.devPara.devParaConf.pidJinneng+"</option><option value='1'>"+Msg.rwmenu.devPara.devParaConf.pidEnable+"</option></select>";
								}
							}
						}
						if(trInputOld == trInput){
							trSelects += "</td><td></td><td align='center' valign='middle'><span id="+sigLisst[i].id+" title=''></span></td></tr>";
						}else{
							trSelects += "</td></tr>";
						}
						tr.append(trSelects);
						trInputOld = trInput;
					}
					tr.append(trInput);
					flags=false;
					toggleIMD();
					
				}
				if(sigVal != null){
					$("#current").val(sigVal);
				}
				if(num == 1){
					var sigId = [];
					for(var i=0; i<sigLisst.length; i++){
						sigId.push(sigLisst[i].id+"");
					}
					var data = {};
				    data.signalIDs = sigId;
				    data.devID = devIdList[0];
					parent.Webchannel.regBusitype("devSignalSocketListener", function (reSour) {
						var signalVals = reSour[data.devID];
						for(var j=0; j<sigLisst.length; j++){
							if(!signalVals[sigLisst[j].id]){
								break;
							}
							var sigVal = signalVals[sigLisst[j].id][0];
							if(sigLisst[j].sigAddress == 45005){
								if($("#"+sigLisst[j].id + ">option[selected='selected']").html() != sigVal){
									if(sigVal == "PV+负偏置" || sigVal == "PV+negative bias" || sigVal == "PV+負バイアス" || sigVal == "N型" || sigVal == "N type"){
										$("#"+sigLisst[j].id).val(1);
									}else if(sigVal == "PV-正偏置" || sigVal == "PV-positive bias" || sigVal == "PV-順バイアス" || sigVal == "P型" || sigVal == "P type"){
										$("#"+sigLisst[j].id).val(0);
									}else{
										$("#"+sigLisst[j].id).val(-1);
									}
								}
								continue;
							}
							if(sigLisst[j].sigAddress == 45003){
								if($("#"+sigLisst[j].id + ">option[selected='selected']").html() != sigVal){
									if(sigVal == "禁止" || sigVal == "Disabled"){
										$("#"+sigLisst[j].id).val(0);
									}else if(sigVal == "PV/PE"){
										$("#"+sigLisst[j].id).val(1);
									}else if(sigVal == "N/PE"){
										$("#"+sigLisst[j].id).val(2);
									}else if(sigVal == "自动" || sigVal == "Automatic" || sigVal == "自動"){
										$("#"+sigLisst[j].id).val(3);
									}
								}
								continue;
							}
							if(sigLisst[j].sigAddress == 45004){
								if($("#"+sigLisst[j].id + ">option[selected='selected']").html() != sigVal){
									if(sigVal == "禁能" || sigVal == "Disabled"){
										$("#"+sigLisst[j].id).val(0);
									}else if(sigVal == "使能" || sigVal == "Enable" || sigVal == "イネーブル"){
										$("#"+sigLisst[j].id).val(1);
									}
								}
								continue;
							}
							if(sigLisst[j].sigAddress == 45044){
								if($("#"+sigLisst[j].id + ">option[selected='selected']").html() != sigVal){
									if(sigVal == "禁能" || sigVal == "Disabled"){
										$("#"+sigLisst[j].id).val(0);
									}else if(sigVal == "使能" || sigVal == "Enable" || sigVal == "イネーブル"){
										$("#"+sigLisst[j].id).val(1);
									}
									toggleIMD();
								}
								continue;
							}
							if(sigLisst[j].sigAddress == 45001){
								if($("#"+sigLisst[j].id + ">option[selected='selected']").html() != sigVal){
									if(sigVal == "正常" || sigVal == "Disabled"){
										$("#"+sigLisst[j].id).val(0);
									}else if(sigVal == "调试" || sigVal == "Enable" || sigVal == "イネーブル"){
										$("#"+sigLisst[j].id).val(2);
									}
								}
								continue;
							}
							if(sigVal == "—"){
								sigVal = null;
							}
							var colName = getLangs(sigLisst[j].sigAddress,flag);
							if(sigVal == null && (colName == Msg.rwmenu.devPara.devParaConf.BatteryBoardType
									|| colName == Msg.rwmenu.devPara.devParaConf.pidOutputEnable
									|| colName == Msg.rwmenu.devPara.devParaConf.pidControlModes
									|| colName == Msg.stationStatusConfig.compensation)){
								sigVal = -1;
							} else{
								if(undefined != signalKeyVal){
									if(!signalKeyVal[sigLisst[j].id]){
										break;
									}
									var value = signalKeyVal[sigLisst[j].id][0];
									if(sigVal != value){
										$("#"+sigLisst[j].id).val(sigVal);
									}
								}else{
									$("#"+sigLisst[j].id).val(sigVal);
								}
							}
						}
						signalValUpdate(signalVals);						
					});
					if(stopPushFlag == false){
						parent.Webchannel.startPush("devSignalSocketListener", data);
					}
				}
				if(!flag){
					pidOutputVoltage();
					pidCompensatingVoltage();
					maxDCVoltage();	
					imdRecTime();
				}else{
					pidOutputVoltage();
					pidOutputVoltageV2();
					pidjlV2();
					pidbcV2();
					pidzgjlV2();
				}
			}
			$('#sysMainOverlay').hide();
	        $('#delLoading').hide();
	        if (sigLisst != null) {
                for(var i=0; i<sigLisst.length; i++){
                    if (num == 1) {
                        if(sigLisst[i].sigAddress == 45001) {	//工作模式([0,1],0：正常1：调试)	v1/v2
                            if (sigVal[sigLisst[i].id] == 1) {
                                $("#" + Msg.stationStatusConfig.offsetVoltage).parent().find("div").html(Msg.rwmenu.devPara.devParaConf.pid3_debugOutputVoltage);
                            }
                        }
					}
                }
			}
		});
	}
}

var signalValUpdate = function(signalVals){
	if(!signalVals){
		return;
	}
	if(!signalKeyVal){
		signalKeyVal = {};
	}
	for(var i in signalVals){
		signalKeyVal[i] = signalVals[i];
	}
}

function stopWebsocket(){
    var wscha = window.parent.Webchannel;
    wscha.stopPush("devSignalSocketListener");
}

function setpidf(){
	var flag = $("#IMD设备接入").find("select").val();
	if(flag==1){
		sureflags=1;	//使能确定标志
	}else{
		sureflags=0;     //禁能确定标志
	}
	
	stopPushFlag = false;
	var sigList = new Array();
	var num = $("#pid-equipment input[name='target']").length;
	var inputs = $("#pid-equipment input[name='target']");
	var selects = $("#pid-equipment select[name='target']");
	var snum = $("#pid-equipment select[name='target']").length;
	var numNew = $("#pid-equipment input[name='targetNew']").length;
	var inputsNew = $("#pid-equipment input[name='targetNew']");
	var devType = $("#dev").val();
	for(var i=0; i<num; i++){
		var sigs = {};
		sigs.sig = inputs[i].id;
		sigs.val = inputs[i].value;
		sigList[i] = sigs;
	}
	for(var i=0; i<snum; i++){
		var sigs = {};
		sigs.sig = selects[i].id;
		sigs.val = selects[i].value;
		sigList.push(sigs);
	}
	for(var i=0; i<numNew; i++){
		var sigs = {};
		sigs.sig = inputsNew[i].id;
		sigs.val = inputsNew[i].value;
		sigList.push(sigs);
	}
	if(!targetyz(sureflags)){
		App.myMsg(Msg.rwmenu.devPara.devParaConf.errorInfo);
		return;
	}
	if(!pidOutputVoltage()){
		return;
	}
	if(!pidCompensatingVoltage()){
		return;
	}
	if(!maxDCVoltage()){
		return;
	}
	if(!imdRecTime()){
		return;
	}
	if(3 == devType){
		if(!pidjlV2()){
			return;
		}
		if(!pidOutputVoltage()){
			return;
		}
		if(!pidzgjlV2()){
			return;
		}
		if(!pidOutputVoltageV2()){
			return;
		}
		if(!pidbcV2()){
			return;
		}
	}else if(devType == 4 || devType == 5){
		if(!pid3_debugOutputVoltage()){
			return;
		}
		if(devType == 5){
			if(!pid3_repairTime()){
				return;
			}
			if(!pid3_repairVoltage()){
				return;
			}
		}
	}
	$('#delLoadingtText').html(Msg.rwmenu.devPara.devParaConf.pidLoading);
	$('#sysMainOverlay').show();
	$('#delLoading').show();
	$.timeOutAjax("/devices/sigVal",{
		"devIdList":devIdList,
		"sigList":sigList
		},function(res){
			debugger
			var reFlag = false;
			if(res.data[-1].split("+")[0] == "false"){
				reFlag = false;
			}else if (res.data[-1].split("+")[0] == "true"){
				reFlag = true;
			}
			$('#sysMainOverlay').hide();
			$('#delLoading').hide();
			if(res && res.success && reFlag){
				for(var x in res.data){
					var tempSpan = $("span[id='"+x+"'][title='']");
					tempSpan.attr("align", "center");
					tempSpan.attr("valign", "middle");
					if(reFlag){
						if(sureflags==1){
							$("#PID周期运行时间").parent().find("td:last").css("display","block")
							$("#IMD周期运行时间").parent().find("td:last").css("display","block")
						}
						tempSpan.attr("title", Msg.rwmenu.devPara.devParaConf.success);
						tempSpan.css("color", "rgb(0, 222, 21)")
						tempSpan.html(Msg.rwmenu.devPara.devParaConf.success);
						tempSpan.css("display","block");
					}else{
						if(sureflags==1){
							$("#PID周期运行时间").parent().find("td:last").css("display","block")
							$("#IMD周期运行时间").parent().find("td:last").css("display","block")
						}
						tempSpan.attr("title", res.data[x].split("+")[1]);
						tempSpan.css("color", "rgb(255, 0, 0)")
						tempSpan.html(Msg.rwmenu.devPara.devParaConf.fail);
						tempSpan.css("display","block");
					}
				}
				//$("#yincangBtn").hide();
				//$("#closeBtn").show();
			}
			else{
				for(var x in res.data){
					var childFlag = res.data[x].split("+")[0] == "true";
					var tempSpan = $("span[id='"+x+"'][title='']");
					tempSpan.attr("align", "center");
					tempSpan.attr("valign", "middle");
					if(childFlag){
						tempSpan.css("color", "rgb(0, 222, 21)")
						tempSpan.html(Msg.rwmenu.devPara.devParaConf.success);
					}else{
						tempSpan.attr("title", res.data[x].split("+")[1]);
						tempSpan.css("color", "rgb(255, 0, 0)")
						tempSpan.html(Msg.rwmenu.devPara.devParaConf.fail);
					}
				}
				//$("#yincangBtn").hide();
				//$("#closeBtn").show();
			
			}
		},24000,function(){
			timeOutFun();
		});
}
function timeOutFun(){
		$('#sysMainOverlay').hide();
		$('#delLoading').hide();
		document.getElementById('overlay').style.display="none";
		document.getElementById('win_add').style.display="none";
		App.myMsg(Msg.rwmenu.devPara.devParaConf.overTime);
}
function targetyz(sureflags) {
	var selectVal = true;
	var num = $("#pid-equipment input[name='target']").length;
	var inputs = $("#pid-equipment input[name='target']");
	var selects = $("#pid-equipment select[name='target']");
	var snum = $("#pid-equipment select[name='target']").length;
	for(var i=0; i<snum; i++){
		if("IMD控制干接点" == $(selects[i]).parent()[0].id && sureflags==0){
			continue;
		}
		if(-1 == selects[i].value){
			selectVal = false;
		}
	}
	return selectVal;
}
function pid3_debugOutputVoltage(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var devType = $("#dev").val();
	// var isnum = /^[0-9]*$/;
    var numberTest = /^\d*\.?\d{0,1}$/;
	var minValue = 0;
	var maxValue = 500;
	if(5 == devType){
		maxValue = 100;
	}
	for(var i=0; i<valsize; i++){
		if(vals[i].id == '调试输出电压'){
			var val = vals[i].children[0].value;
			if(!numberTest.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
                $("#pid3_debugOutputVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeSize);
				flag = false;
			}
			/*if(vals[i].children[0].value.indexOf(".") != -1){
				$("#pid3_debugOutputVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
				flag = false;
			}*/
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < minValue || vals[i].children[0].value > maxValue){
				$("#pid3_debugOutputVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
				flag = false;
			}
			else{
				$("#pid3_debugOutputVoltage").html("");
			}
		}
	}
	return flag;
}

function pid3_repairTime(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var devType = $("#dev").val();
	var isnum = /^\d{1}(\.\d{1})?$/;
	var minValue = 0;
	var maxValue = 6;
	
	for(var i=0; i<valsize; i++){
		if(vals[i].id == '修复时间'){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				if(val*1 <0 || val*1>6){
					$("#pid3_repairTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
				}else{
					$("#pid3_repairTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ2);
				}
				flag = false;
			}
//			if(vals[i].children[0].value.indexOf(".") != -1){
//				$("#pid3_repairTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
//				flag = false;
//			}
			if(flag){
				if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < minValue || vals[i].children[0].value > maxValue){
					$("#pid3_repairTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
					flag = false;
				}
				else{
					$("#pid3_repairTime").html("");
				}
			}
		}
	}
	return flag;
}

function pid3_repairVoltage(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var devType = $("#dev").val();
	var isnum = /^[0-9]*$/;
	var minValue = 50;
	var maxValue = 500;
	
	for(var i=0; i<valsize; i++){
		if(vals[i].id == '修复电压'){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") != -1){
				$("#pid3_repairVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
				flag = false;
			}
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < minValue || vals[i].children[0].value > maxValue){
				$("#pid3_repairVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
				flag = false;
			}
			else{
				$("#pid3_repairVoltage").html("");
			}
		}
	}
	return flag;
}


function pidOutputVoltage(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var devType = $("#dev").val();
	var isnum = /^[0-9]*$/;
	var minValue = 0;
	var maxValue = 500;
	if(3 == devType){
		maxValue = 800;
	}
	for(var i=0; i<valsize; i++){
		if(vals[i].id == '最高输出电压'){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") != -1){
				$("#pidOutputVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
				flag = false;
			}
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < minValue || vals[i].children[0].value > maxValue){
				$("#pidOutputVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
				flag = false;
			}
			else{
				$("#pidOutputVoltage").html("");
			}
		}
	}
	return flag;
}

function pidCompensatingVoltage(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var sigvals = $("#pid-equipment td[name='signame'] input");
	var isnum = /^\d+(\.\d+)?$/;
	for(var i=0; i<valsize; i++){
		if(vals[i].id == 'PV/PE补偿电压'){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") > -1 && !(vals[i].children[0].value.split(".")[1].length == 1)){
				$("#pidCompensatingVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeSize);
				flag = false;
			}
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < 0 || vals[i].children[0].value > 200){
				$("#pidCompensatingVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+"0-200");
				flag = false;
			}
			else{
				$("#pidCompensatingVoltage").html("");
			}
		}
	}
	return flag;
}

function maxDCVoltage(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var sigvals = $("#pid-equipment td[name='signame'] input");
	var isnum = /^[0-9]*$/;
	for(var i=0; i<valsize; i++){
		if(vals[i].id == '系统最高直流电压'){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") != -1){
				$("#maxDCVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
				flag = false;
			}
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < 500 || vals[i].children[0].value > 1500){
				$("#maxDCVoltage").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+"500-1500");
				flag = false;
			}
			else{
				$("#maxDCVoltage").html("");
			}
		}
	}
	return flag;
}

function imdRecTime(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var isnum = /^[0-9]*$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var sigvals = $("#pid-equipment td[name='signame'] input");
	var selectflag = $("#IMD设备接入").find("select").val();
	for(var i=0; i<valsize; i++){
		if(vals[i].id == "IMD周期运行时间"){
			var val = vals[i].children[0].value;
			if(selectflag == 0){	//隐藏状态
//				$("#"+vals[i].children[0].id).val("");
				flag = true;
			}else{
				if(!isnum.test(vals[i].children[0].value)){
					val = val.replace(/[^\-?\d.]/g,'');
					var id = vals[i].children[0].id;
					$("#"+id).val(val);
					flag = false;
				}
				if(val.indexOf(".") != -1){
					$("#imdRecTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
					flag = false;
				}
				else if(!yz.test(val) || val < 15 || val > 480){
					$("#imdRecTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+"15-480");
					flag = false;
				}else{
					$("#imdRecTime").html("");
				}
			}
			
			
		}
		if(vals[i].id == "PID周期运行时间"){
			var val = vals[i].children[0].value;
			if(selectflag == 0){
//				$("#"+vals[i].children[0].id).val("");
				flag = true;
			}else{
				if(!isnum.test(vals[i].children[0].value)){
					val = val.replace(/[^\-?\d.]/g,'');
					var id = vals[i].children[0].id;
					$("#"+id).val(val);
					$("#"+id).html("1");
					flag = false;
				}
				if(vals[i].children[0].value.indexOf(".") != -1){
					$("#pidRecTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
					flag = false;
				}
				else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < 60 || vals[i].children[0].value > 480){
					$("#pidRecTime").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+"60-480");
					flag = false;
				}else{
					$("#pidRecTime").html("");
				}
			}
		}
	}
	return flag;
}

function toggleIMD(){
	debugger
	imdRecTime();
	var flag = $("#IMD设备接入").find("select").val();
	var tds = [];
	var devType = $("#dev").val();
	tds.push($("#PID周期运行时间").parent());
	tds.push($("#IMD周期运行时间").parent());
	if(devType==2){
		tds.push($("#IMD控制干接点").parent());
	}
	for(var i=0; i < tds.length; i++){
		if(flag == 0){
			tds[i].hide();
//			$("#"+tds[i].children()[1].children[0].id).val("");
			flags=true;
		}else{
			tds[i].show();
			//sureflags  使能确定标志 1  禁能确定标志0
			//flag  使能确定标志 1  禁能确定标志0
			if(sureflags==0 && flag==1 &&(tds[i].children()[1].id == "IMD周期运行时间" || tds[i].children()[1].id == "PID周期运行时间" ||tds[i].children()[1].id == "交流对地阻抗告警点")){
				tds[i].children()[3].style.display="block";
			}
			if(tds[i].children()[1]!=undefined && ("" == tds[i].children()[1].children[0].value || null == tds[i].children()[1].children[0].value) ){
//				$("#"+tds[i].children()[1].children[0].id).val("1");
				flags=false;
			}
			

		}
	}
}

function getLangs(s,flag){	//原判断信号点名称修改为判断信号点地址	flag 是否为PIDV2版本
	if(s == 45003){	//补偿方式
		return Msg.rwmenu.devPara.devParaConf.pidControlModes;
	}else if(s == 45005 && !flag){	//电池板类型V1
		return Msg.rwmenu.devPara.devParaConf.BatteryBoardType;
	}else if(s == 45007){	//最高输出电压
		return Msg.rwmenu.devPara.devParaConf.pidOutputVoltage;
	}else if(s == 45006){	//PV/PE补偿电压V1
		return Msg.rwmenu.devPara.devParaConf.pidCompensatingVoltage;
	}else if(s == 45021 && !flag){	//系统最高直流电压V1
		return Msg.rwmenu.devPara.devParaConf.maxDCVoltage;
	} else if(s == 45005 && flag){	//电池板补偿电压方向	V2
		return Msg.stationStatusConfig.compensationlag;
	}else if(s == 45021 && flag){	//系统最高直流对地耐压 V2
		return Msg.stationStatusConfig.maximumlag;
	} else if(s == 45022){	//交流对地阻抗告警点
		return Msg.stationStatusConfig.impedancelag;
	} else if(s == 45023){	//补偿偏置电压
		return Msg.stationStatusConfig.offsetVoltagelag;
	} else if(s == 45029){	//系统最高交流对地耐压
		return Msg.stationStatusConfig.maximumAClag;
	}else if(s == 45046){	//IMD周期运行时间
		return Msg.rwmenu.devPara.devParaConf.IMDRunningPeriod;
	}else if(s == 45045){	//PID周期运行时间
		return Msg.rwmenu.devPara.devParaConf.pidRunningPeriod;
	}else if(s == 45044){	//IMD设备接入
		return Msg.rwmenu.devPara.devParaConf.IMDaccess;
	}else if(s == 45001){	//工作模式
		return Msg.rwmenu.devPara.devParaConf.pidWorkWay;
	}else if(s == 45047){	//IMD控制干接点
		return Msg.rwmenu.devPara.devParaConf.IMDControl;
	}else if(s == 45004){	//输出使能  V1
		return Msg.rwmenu.devPara.devParaConf.pidOutputEnable;
	}else if(s == 45002){	//调试输出电压
		return Msg.rwmenu.devPara.devParaConf.pid3_debugOutputVoltage;
	}else if(s == 45020){	//数据清除
		return Msg.rwmenu.devPara.devParaConf.pid3_cleanData;
	}else if(s == 45059){	//修复时间
		return Msg.rwmenu.devPara.devParaConf.pid3_repairTime;
	}else if(s == 45060){	//修复电压
		return Msg.rwmenu.devPara.devParaConf.pid3_repairVoltage;
	}
}

function pidjlV2(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var sigvals = $("#pid-equipment td[name='signame'] input");
	var isnum = /^\d+(\.\d+)?$/;
	for(var i=0; i<valsize; i++){
		if(vals[i].id == Msg.stationStatusConfig.impedance){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") != -1 && vals[i].children[0].value.split(".")[1].length > 1){
				$("#pidjlVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeSize);
				flag = false;
			}else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < 0.2 || vals[i].children[0].value > 100){
				$("#pidjlVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+"0.2-100");
				flag = false;
			}
			else{
				$("#pidjlVoltageV2").html("");
			}
		}
	}
	return flag;
}

function pidzgjlV2(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var sigvals = $("#pid-equipment td[name='signame'] input");
	var isnum = /^\d+(\.\d+)?$/;
	var minValue = 450;
	var maxValue = 1800;
	for(var i=0; i<valsize; i++){
		if(vals[i].id == Msg.stationStatusConfig.maximumAC){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") != -1 && !(vals[i].children[0].value.split(".")[1].length == 1)){
				$("#pidzgjlVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeSize);
				flag = false;
			}
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < minValue || vals[i].children[0].value > maxValue){
				$("#pidzgjlVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
				flag = false;
			}
			else{
				$("#pidzgjlVoltageV2").html("");
			}
		}
	}
	return flag;
}

function pidOutputVoltageV2(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var sigvals = $("#pid-equipment td[name='signame'] input");
	var isnum = /^[0-9]*$/;
	var minValue = 500;
	var maxValue = 1500;
	for(var i=0; i<valsize; i++){
		if(vals[i].id == Msg.stationStatusConfig.maximum){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") != -1){
				$("#pidOutputVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeZ);
				flag = false;
			}
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < minValue || vals[i].children[0].value > maxValue){
				$("#pidOutputVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
				flag = false;
			}
			else{
				$("#pidOutputVoltageV2").html("");
			}
		}
	}
	return flag;
}

function pidbcV2(){
	var flag = true;
	var yz = /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/;
	var vals = $("#pid-equipment td[name='signame']");
	var valsize = $("#pid-equipment td[name='signame']").length;
	var sigvals = $("#pid-equipment td[name='signame'] input");
	var isnum = /^\d+(\.\d+)?$/;
	var minValue = 0;
	var maxValue = 500;
	for(var i=0; i<valsize; i++){
		if(vals[i].id == Msg.stationStatusConfig.offsetVoltage){
			var val = vals[i].children[0].value;
			if(!isnum.test(vals[i].children[0].value)){
				val = val.replace(/[^\-?\d.]/g,'');
				var id = vals[i].children[0].id;
				$("#"+id).val(val);
				flag = false;
			}
			if(vals[i].children[0].value.indexOf(".") != -1 && !(vals[i].children[0].value.split(".")[1].length == 1)){
				$("#pidbcVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRangeSize);
				flag = false;
			}
			else if(!yz.test(vals[i].children[0].value) || vals[i].children[0].value < minValue || vals[i].children[0].value > maxValue){
				$("#pidbcVoltageV2").html(Msg.rwmenu.devPara.devParaConf.pidInputRange+minValue+"-"+maxValue);
				flag = false;
			}
			else{
				$("#pidbcVoltageV2").html("");
			}
		}
	}
	return flag;
}

//function languageChange(lang){
//	debugger
//	if(lang == "zh"){
//		var totalNumHtml = $("#totalNum1").text();
//		if(totalNumHtml.charAt(totalNumHtml.length - 1) == "s"){
//			$("#totalNum1").html(totalNumHtml.substring(0,totalNumHtml.length-1));
//		}
//	}
//	
//	if(lang == "en_us" || lang == "en_uk"){//当前语言为英文才进行后续操作
//		setPlural("totalNum","totalNum1");
//		setPlural("totalPageId","totalPageId1");
//	}
//}
/**
 * pid2.0下过模式修改展示
 * @param e
 */
function changeOperatingMode(e) {
	var dev = $("#dev").val();
	var mode = $(e).val();
	if (dev == 3) {
		if (mode == 1) {
			$("#" + Msg.stationStatusConfig.offsetVoltage).parent().find("div").html(Msg.rwmenu.devPara.devParaConf.pid3_debugOutputVoltage);
		} else {
            $("#" + Msg.stationStatusConfig.offsetVoltage).parent().find("div").html(Msg.stationStatusConfig.offsetVoltage);
		}
	}
}